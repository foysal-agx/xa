"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import { Share2, Sun, Moon } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { cn } from "@/lib/utils"
import { useTheme } from "next-themes"
import { motion } from "framer-motion"

export default function ProfilePage() {
  const [activeTab, setActiveTab] = useState("posts")
  const [isFollowing, setIsFollowing] = useState(false)
  const { setTheme } = useTheme()
  const [mounted, setMounted] = useState(false)
  const [currentTheme, setCurrentTheme] = useState("dark")

  // Handle theme toggle
  useEffect(() => {
    setMounted(true)
    // Check for system preference or stored preference
    const savedTheme = localStorage.getItem("theme") || "dark"
    setCurrentTheme(savedTheme)
    setTheme(savedTheme)
  }, [setTheme])

  const toggleTheme = () => {
    const newTheme = currentTheme === "dark" ? "light" : "dark"
    setCurrentTheme(newTheme)
    setTheme(newTheme)
    localStorage.setItem("theme", newTheme)
  }

  const toggleFollow = () => {
    setIsFollowing(!isFollowing)
  }

  const shareProfile = async () => {
    const shareData = {
      title: "FoYSaL Profile",
      text: "Check out FoYSaL's profile!",
      url: window.location.href,
    }

    try {
      if (navigator.share) {
        await navigator.share(shareData)
      } else {
        // Fallback for browsers that don't support navigator.share
        alert("Copy this link to share: " + window.location.href)
      }
    } catch (err) {
      console.error("Error sharing:", err)
    }
  }

  return (
    <div className="flex min-h-screen flex-col bg-background text-foreground">
      {/* Theme Toggle */}
      <div className="absolute right-4 top-4">
        <Button variant="ghost" size="icon" onClick={toggleTheme} className="rounded-full">
          {mounted && currentTheme === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
          <span className="sr-only">Toggle theme</span>
        </Button>
      </div>

      {/* Profile Header */}
      <div className="mx-auto w-full max-w-md px-4 pt-16 sm:max-w-lg">
        <div className="flex flex-col items-center">
          {/* Profile Image with Animation */}
          <motion.div
            className="relative mb-4 h-28 w-28 overflow-hidden rounded-full border-2 border-orange-500"
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ type: "spring", stiffness: 260, damping: 20 }}
          >
            <Image src="/images/profile-new.jpeg" alt="Profile" fill className="object-cover" priority />
          </motion.div>

          {/* Username with Animation */}
          <motion.div
            className="mb-4 flex items-center gap-1 text-center"
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.2, duration: 0.5 }}
          >
            <span className="text-lg">FoYSaL</span>
            <span className="text-orange-500">🔥</span>
            <span>💿</span>
            <span>🍎</span>
          </motion.div>

          {/* Action Buttons */}
          <motion.div
            className="mb-6 flex w-full max-w-xs gap-2"
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.3, duration: 0.5 }}
          >
            <Button
              className={cn(
                "flex-1 rounded-full font-medium",
                isFollowing
                  ? "bg-zinc-800 text-white hover:bg-zinc-700 dark:bg-zinc-700 dark:hover:bg-zinc-600"
                  : "bg-rose-600 hover:bg-rose-700",
              )}
              onClick={toggleFollow}
            >
              {isFollowing ? "Following" : "Follow"}
            </Button>
            <Button
              variant="outline"
              size="icon"
              className="rounded-full border-zinc-300 hover:bg-accent hover:text-accent-foreground dark:border-zinc-700"
              onClick={shareProfile}
            >
              <Share2 className="h-5 w-5" />
            </Button>
          </motion.div>

          {/* Stats with Animation */}
          <motion.div
            className="mb-4 flex w-full justify-center gap-6 text-center"
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.4, duration: 0.5 }}
          >
            <div className="flex flex-col">
              <span className="font-bold">0</span>
              <span className="text-sm text-muted-foreground">Following</span>
            </div>
            <div className="flex flex-col">
              <span className="font-bold">23.9K</span>
              <span className="text-sm text-muted-foreground">Followers</span>
            </div>
          </motion.div>

          {/* Bio */}
          <motion.div
            className="mb-6 text-center"
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.5, duration: 0.5 }}
          >
            <p className="mb-1">
              Focus On Goal <span>💋</span>
            </p>
            <p className="mb-2 text-sm text-muted-foreground">লা ইলাহা ইল্লাল্লাহু মুহাম্মাদুর রাসূলুল্লাহ</p>
          </motion.div>
        </div>

        {/* Tabs */}
        <Tabs defaultValue="posts" className="w-full" onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-1 bg-transparent">
            <TabsTrigger
              value="posts"
              className={cn(
                "border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent data-[state=active]:shadow-none",
                activeTab === "posts" ? "border-primary" : "",
              )}
            >
              <DocumentText className="mr-2 h-4 w-4" /> Posts
            </TabsTrigger>
          </TabsList>

          {/* Content */}
          <TabsContent value="posts" className="mt-6">
            <div className="grid grid-cols-3 gap-1">
              {/* Post 1 */}
              <div className="relative aspect-[3/4] overflow-hidden rounded-md">
                <Image src="/images/post1.jpeg" alt="Post thumbnail" fill className="object-cover" />
              </div>

              {/* Post 2 */}
              <div className="relative aspect-[3/4] overflow-hidden rounded-md">
                <Image src="/images/post2.jpeg" alt="Post thumbnail" fill className="object-cover" />
              </div>

              {/* Post 3 */}
              <div className="relative aspect-[3/4] overflow-hidden rounded-md">
                <Image src="/images/post3.jpeg" alt="Post thumbnail" fill className="object-cover" />
              </div>

              {/* Post 4 */}
              <div className="relative aspect-[3/4] overflow-hidden rounded-md">
                <Image src="/images/post4.jpeg" alt="Post thumbnail" fill className="object-cover" />
              </div>

              {/* Post 5 */}
              <div className="relative aspect-[3/4] overflow-hidden rounded-md">
                <Image src="/images/post5.jpeg" alt="Post thumbnail" fill className="object-cover" />
              </div>

              {/* Post 6 - Using profile image as 6th image since only 5 were provided */}
              <div className="relative aspect-[3/4] overflow-hidden rounded-md">
                <Image src="/images/profile-new.jpeg" alt="Post thumbnail" fill className="object-cover" />
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Footer with developer credit */}
      <div className="mt-10 py-4 text-center text-sm text-muted-foreground">DEV -AGXBD</div>
    </div>
  )
}

function DocumentText(props) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M14 2v4a2 2 0 0 0 2 2h4" />
      <path d="M18 18v-7h-7" />
      <path d="M18 18H9a2 2 0 0 1-2-2v-1" />
      <path d="M3 7v10a2 2 0 0 0 2 2h4" />
      <rect width="4" height="6" x="3" y="2" rx="2" />
      <path d="M11 13h4" />
      <path d="M11 18h4" />
    </svg>
  )
}
